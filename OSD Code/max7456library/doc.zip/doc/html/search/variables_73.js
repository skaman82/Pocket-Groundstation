var searchData=
[
  ['softwareresetbit',['softwareResetBit',['../union_r_e_g___v_m0.html#a3eadddb1530430f2048e201120a323c9',1,'REG_VM0']]],
  ['synchselect',['synchSelect',['../union_r_e_g___v_m0.html#a7b4c9c51f76637284cda8d298b3df1e9',1,'REG_VM0']]]
];
