var searchData=
[
  ['vm0_5faddress_5fread',['VM0_ADDRESS_READ',['../max7456_registers_8h.html#a42bbf6fcd7aeecc6eb3ddd833fc326ce',1,'max7456Registers.h']]],
  ['vm0_5faddress_5fwrite',['VM0_ADDRESS_WRITE',['../max7456_registers_8h.html#a8e7ce18bd0f7f2d74a7eb5f3568bbb34',1,'max7456Registers.h']]],
  ['vm1_5faddress_5fread',['VM1_ADDRESS_READ',['../max7456_registers_8h.html#af5dfb6642c6e9e336e30879b6dbbf512',1,'max7456Registers.h']]],
  ['vm1_5faddress_5fwrite',['VM1_ADDRESS_WRITE',['../max7456_registers_8h.html#acee7b83597e3411413d317c022ba8244',1,'max7456Registers.h']]],
  ['vos_5faddress_5fread',['VOS_ADDRESS_READ',['../max7456_registers_8h.html#a2b2e55b6c92cb9239fd56fb86e804200',1,'max7456Registers.h']]],
  ['vos_5faddress_5fwrite',['VOS_ADDRESS_WRITE',['../max7456_registers_8h.html#a706bb7566ad5a293f9eba0b3c17a7786',1,'max7456Registers.h']]]
];
