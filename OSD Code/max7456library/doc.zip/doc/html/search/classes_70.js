var searchData=
[
  ['pixel',['PIXEL',['../struct_p_i_x_e_l.html',1,'']]]
];
