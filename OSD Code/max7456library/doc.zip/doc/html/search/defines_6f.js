var searchData=
[
  ['osdbl_5faddress_5fread',['OSDBL_ADDRESS_READ',['../max7456_registers_8h.html#a762dd39bde54f7c37088d988eaf0349e',1,'max7456Registers.h']]],
  ['osdbl_5faddress_5fwrite',['OSDBL_ADDRESS_WRITE',['../max7456_registers_8h.html#ac783e3097c6cf89cea3f34b33e5650a4',1,'max7456Registers.h']]],
  ['osdm_5faddress_5fread',['OSDM_ADDRESS_READ',['../max7456_registers_8h.html#a7b62e0776857e2a33faf26ecc9b0fc81',1,'max7456Registers.h']]],
  ['osdm_5faddress_5fwrite',['OSDM_ADDRESS_WRITE',['../max7456_registers_8h.html#a042a53a0064ee9fd7504ca7986afd97f',1,'max7456Registers.h']]]
];
