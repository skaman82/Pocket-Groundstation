var searchData=
[
  ['max7456',['Max7456',['../class_max7456.html#afe4e2a6b8061656a803d42a2944fbabd',1,'Max7456::Max7456()'],['../class_max7456.html#a858413a04276a595e27609e5507cd76b',1,'Max7456::Max7456(byte pinCS)']]]
];
